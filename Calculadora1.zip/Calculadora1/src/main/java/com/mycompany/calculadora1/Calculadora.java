
package com.mycompany.calculadora1;




public class Calculadora extends javax.swing.JFrame {
 
    float x, y, z;
    String signo;

    public Calculadora() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtOperacion = new javax.swing.JLabel();
        txtResultado = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_c = new javax.swing.JButton();
        btn_ac = new javax.swing.JButton();
        btn_exp = new javax.swing.JButton();
        btn_div = new javax.swing.JButton();
        btn_IVA = new javax.swing.JButton();
        btn_sin = new javax.swing.JButton();
        btn_cos = new javax.swing.JButton();
        btn_tan = new javax.swing.JButton();
        btn_7 = new javax.swing.JButton();
        btn_8 = new javax.swing.JButton();
        btn_9 = new javax.swing.JButton();
        btn_mul = new javax.swing.JButton();
        btn_4 = new javax.swing.JButton();
        btn_5 = new javax.swing.JButton();
        btn_6 = new javax.swing.JButton();
        btn_men = new javax.swing.JButton();
        btn_1 = new javax.swing.JButton();
        btn_2 = new javax.swing.JButton();
        btn_3 = new javax.swing.JButton();
        btn_sum = new javax.swing.JButton();
        btn_0 = new javax.swing.JButton();
        btn_00 = new javax.swing.JButton();
        btn_Raiz = new javax.swing.JButton();
        btn_igual = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(161, 96, 251));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtOperacion.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        txtOperacion.setForeground(new java.awt.Color(75, 75, 75));
        txtOperacion.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(txtOperacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 32, 440, 30));

        txtResultado.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 36)); // NOI18N
        txtResultado.setForeground(new java.awt.Color(75, 75, 75));
        txtResultado.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        txtResultado.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(txtResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 68, 440, 82));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 160));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_c.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_c.setForeground(new java.awt.Color(75, 75, 75));
        btn_c.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_c.setText("C");
        btn_c.setBorderPainted(false);
        btn_c.setFocusPainted(false);
        btn_c.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_c.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_c.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cActionPerformed(evt);
            }
        });
        jPanel2.add(btn_c, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 50));

        btn_ac.setFont(new java.awt.Font("Rockwell", 0, 12)); // NOI18N
        btn_ac.setForeground(new java.awt.Color(75, 75, 75));
        btn_ac.setIcon(new javax.swing.ImageIcon("E:\\Apps\\Proyectos\\Calculadora\\src\\main\\java\\com\\mycompany\\calculadora\\btn1.png")); // NOI18N
        btn_ac.setText("AC");
        btn_ac.setBorderPainted(false);
        btn_ac.setFocusPainted(false);
        btn_ac.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_ac.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_ac.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_ac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_acActionPerformed(evt);
            }
        });
        jPanel2.add(btn_ac, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 50, 50));

        btn_exp.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_exp.setForeground(new java.awt.Color(75, 75, 75));
        btn_exp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_exp.setText("^");
        btn_exp.setBorderPainted(false);
        btn_exp.setFocusPainted(false);
        btn_exp.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_exp.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_exp.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_exp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_expActionPerformed(evt);
            }
        });
        jPanel2.add(btn_exp, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 50, 50));

        btn_div.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_div.setForeground(new java.awt.Color(75, 75, 75));
        btn_div.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_div.setText("/");
        btn_div.setBorderPainted(false);
        btn_div.setFocusPainted(false);
        btn_div.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_div.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_div.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_div.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_divActionPerformed(evt);
            }
        });
        jPanel2.add(btn_div, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 50, 50));

        btn_IVA.setFont(new java.awt.Font("Rockwell", 0, 12)); // NOI18N
        btn_IVA.setForeground(new java.awt.Color(75, 75, 75));
        btn_IVA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_IVA.setText("IVA");
        btn_IVA.setBorderPainted(false);
        btn_IVA.setFocusPainted(false);
        btn_IVA.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_IVA.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_IVA.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_IVA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_IVAActionPerformed(evt);
            }
        });
        jPanel2.add(btn_IVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, 50, 50));

        btn_sin.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        btn_sin.setForeground(new java.awt.Color(75, 75, 75));
        btn_sin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_sin.setText("Sin");
        btn_sin.setBorderPainted(false);
        btn_sin.setFocusPainted(false);
        btn_sin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_sin.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_sin.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_sin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sinActionPerformed(evt);
            }
        });
        jPanel2.add(btn_sin, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 90, 50, 50));

        btn_cos.setFont(new java.awt.Font("Rockwell", 0, 11)); // NOI18N
        btn_cos.setForeground(new java.awt.Color(75, 75, 75));
        btn_cos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_cos.setText("Cos");
        btn_cos.setBorderPainted(false);
        btn_cos.setFocusPainted(false);
        btn_cos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_cos.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_cos.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_cos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cosActionPerformed(evt);
            }
        });
        jPanel2.add(btn_cos, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 50, 50));

        btn_tan.setFont(new java.awt.Font("Rockwell", 0, 11)); // NOI18N
        btn_tan.setForeground(new java.awt.Color(75, 75, 75));
        btn_tan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_tan.setText("Tan");
        btn_tan.setBorderPainted(false);
        btn_tan.setFocusPainted(false);
        btn_tan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_tan.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_tan.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_tan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tanActionPerformed(evt);
            }
        });
        jPanel2.add(btn_tan, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 250, 50, 50));

        btn_7.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_7.setForeground(new java.awt.Color(75, 75, 75));
        btn_7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_7.setText("7");
        btn_7.setBorderPainted(false);
        btn_7.setFocusPainted(false);
        btn_7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_7.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_7.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_7ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 50, 50));

        btn_8.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_8.setForeground(new java.awt.Color(75, 75, 75));
        btn_8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_8.setText("8");
        btn_8.setBorderPainted(false);
        btn_8.setFocusPainted(false);
        btn_8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_8.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_8.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_8ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 50, 50));

        btn_9.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_9.setForeground(new java.awt.Color(75, 75, 75));
        btn_9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_9.setText("9");
        btn_9.setBorderPainted(false);
        btn_9.setFocusPainted(false);
        btn_9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_9.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_9.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_9ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 50, 50));

        btn_mul.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_mul.setForeground(new java.awt.Color(75, 75, 75));
        btn_mul.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_mul.setText("*");
        btn_mul.setBorderPainted(false);
        btn_mul.setFocusPainted(false);
        btn_mul.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_mul.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_mul.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_mul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mulActionPerformed(evt);
            }
        });
        jPanel2.add(btn_mul, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 90, 50, 50));

        btn_4.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_4.setForeground(new java.awt.Color(75, 75, 75));
        btn_4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_4.setText("4");
        btn_4.setBorderPainted(false);
        btn_4.setFocusPainted(false);
        btn_4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_4.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_4.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_4ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 50, 50));

        btn_5.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_5.setForeground(new java.awt.Color(75, 75, 75));
        btn_5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_5.setText("5");
        btn_5.setBorderPainted(false);
        btn_5.setFocusPainted(false);
        btn_5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_5.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_5.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_5ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 50, 50));

        btn_6.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_6.setForeground(new java.awt.Color(75, 75, 75));
        btn_6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_6.setText("6");
        btn_6.setBorderPainted(false);
        btn_6.setFocusPainted(false);
        btn_6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_6.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_6.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_6ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 50, 50));

        btn_men.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_men.setForeground(new java.awt.Color(75, 75, 75));
        btn_men.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_men.setText("-");
        btn_men.setBorderPainted(false);
        btn_men.setFocusPainted(false);
        btn_men.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_men.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_men.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_men.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_menActionPerformed(evt);
            }
        });
        jPanel2.add(btn_men, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 50, 50));

        btn_1.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_1.setForeground(new java.awt.Color(75, 75, 75));
        btn_1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_1.setText("1");
        btn_1.setBorderPainted(false);
        btn_1.setFocusPainted(false);
        btn_1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_1.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_1.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_1ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 50, 50));

        btn_2.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_2.setForeground(new java.awt.Color(75, 75, 75));
        btn_2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_2.setText("2");
        btn_2.setBorderPainted(false);
        btn_2.setFocusPainted(false);
        btn_2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_2.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_2.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_2ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 50, 50));

        btn_3.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_3.setForeground(new java.awt.Color(75, 75, 75));
        btn_3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_3.setText("3");
        btn_3.setBorderPainted(false);
        btn_3.setFocusPainted(false);
        btn_3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_3.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_3.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_3ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 50, 50));

        btn_sum.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_sum.setForeground(new java.awt.Color(75, 75, 75));
        btn_sum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_sum.setText("+");
        btn_sum.setBorderPainted(false);
        btn_sum.setFocusPainted(false);
        btn_sum.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_sum.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_sum.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_sum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sumActionPerformed(evt);
            }
        });
        jPanel2.add(btn_sum, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 50, 50));

        btn_0.setFont(new java.awt.Font("Rockwell", 0, 24)); // NOI18N
        btn_0.setForeground(new java.awt.Color(75, 75, 75));
        btn_0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_0.setText("0");
        btn_0.setBorderPainted(false);
        btn_0.setFocusPainted(false);
        btn_0.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_0.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_0.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_0ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_0, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, 50, 50));

        btn_00.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        btn_00.setForeground(new java.awt.Color(75, 75, 75));
        btn_00.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_00.setText("00");
        btn_00.setBorderPainted(false);
        btn_00.setFocusPainted(false);
        btn_00.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_00.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_00.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_00.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_00ActionPerformed(evt);
            }
        });
        jPanel2.add(btn_00, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 50, 50));

        btn_Raiz.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        btn_Raiz.setForeground(new java.awt.Color(75, 75, 75));
        btn_Raiz.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/calculadora1/btn1.png"))); // NOI18N
        btn_Raiz.setText("√");
        btn_Raiz.setBorderPainted(false);
        btn_Raiz.setFocusPainted(false);
        btn_Raiz.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Raiz.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_Raiz.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_Raiz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_RaizActionPerformed(evt);
            }
        });
        jPanel2.add(btn_Raiz, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 330, 50, 50));

        btn_igual.setFont(new java.awt.Font("Rockwell", 0, 30)); // NOI18N
        btn_igual.setForeground(new java.awt.Color(255, 255, 255));
        btn_igual.setIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_igual.setText("=");
        btn_igual.setBorderPainted(false);
        btn_igual.setFocusPainted(false);
        btn_igual.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_igual.setPressedIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn1.png")); // NOI18N
        btn_igual.setRolloverIcon(new javax.swing.ImageIcon("C:\\Users\\user\\Documents\\NetBeansProjects\\Calculadora1\\src\\imagenes\\btn2.png")); // NOI18N
        btn_igual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_igualActionPerformed(evt);
            }
        });
        jPanel2.add(btn_igual, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 330, 50, 50));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 450, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cActionPerformed
        txtOperacion.setText("");
        txtResultado.setText("");
    }//GEN-LAST:event_btn_cActionPerformed

    private void btn_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_7ActionPerformed
        addNumber("7");
    }//GEN-LAST:event_btn_7ActionPerformed

    private void btn_8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_8ActionPerformed
        addNumber("8");
    }//GEN-LAST:event_btn_8ActionPerformed

    private void btn_9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_9ActionPerformed
        addNumber("9");
    }//GEN-LAST:event_btn_9ActionPerformed

    private void btn_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_4ActionPerformed
        addNumber("4");
    }//GEN-LAST:event_btn_4ActionPerformed

    private void btn_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_5ActionPerformed
        addNumber("5");
    }//GEN-LAST:event_btn_5ActionPerformed

    private void btn_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_6ActionPerformed
        addNumber("6");
    }//GEN-LAST:event_btn_6ActionPerformed

    private void btn_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_1ActionPerformed
        addNumber("1");
    }//GEN-LAST:event_btn_1ActionPerformed

    private void btn_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_2ActionPerformed
        addNumber("2");
    }//GEN-LAST:event_btn_2ActionPerformed

    private void btn_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_3ActionPerformed
        addNumber("3");
    }//GEN-LAST:event_btn_3ActionPerformed

    private void btn_0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_0ActionPerformed
        addNumber("0");
    }//GEN-LAST:event_btn_0ActionPerformed

    private void btn_00ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_00ActionPerformed
        addNumber("00");
    }//GEN-LAST:event_btn_00ActionPerformed

    private void btn_RaizActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_RaizActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "√";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_RaizActionPerformed

    private void btn_expActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_expActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "^";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_expActionPerformed

    private void btn_divActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_divActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "/";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_divActionPerformed

    private void btn_IVAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_IVAActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "IVA";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_IVAActionPerformed

    private void btn_mulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mulActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "*";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_mulActionPerformed

    private void btn_menActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_menActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "-";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_menActionPerformed

    private void btn_sumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sumActionPerformed
        x=Integer.parseInt(txtOperacion.getText());
        signo = "+";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_sumActionPerformed

    private void btn_sinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sinActionPerformed
        /*x=Integer.parseInt(txtOperacion.getText());*/
        signo = "Sin";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_sinActionPerformed

    private void btn_cosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cosActionPerformed
        /*x=Integer.parseInt(txtOperacion.getText());*/
        signo = "Cos";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_cosActionPerformed

    private void btn_tanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tanActionPerformed
       /* x=Integer.parseInt(txtOperacion.getText());*/
        signo = "Tan";
        txtOperacion.setText("");
    }//GEN-LAST:event_btn_tanActionPerformed

    private void btn_igualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_igualActionPerformed
        y = Integer.parseInt(txtOperacion.getText());
        
        switch(signo){
            case "+" -> {
                txtResultado.setText(Float.toString(x+y));
                txtOperacion.setText("");
            }
            case "-" -> {
                txtResultado.setText(Float.toString(x-y));
                txtOperacion.setText("");
            }
            case "*" -> {
                txtResultado.setText(Float.toString(x*y));
                txtOperacion.setText("");
            }
            case "/" -> {
                txtResultado.setText(Float.toString(x/y));
                txtOperacion.setText("");
            }
            case "^" -> {
                txtResultado.setText(Float.toString((float) Math.pow(x, y)));
                txtOperacion.setText("");
            }
            case"√" -> {
                if (x < 0){
                    System.out.println("ERROR");
                } else {
                    z = (float) Math.pow(x,(1/y));
                    txtResultado.setText(Float.toString(z));
                    txtOperacion.setText("");
                }
            }
            case "Sin" -> {
                if(y== 180 || y== 360 || y== 540 || y== 720 || y== 900 || y== 1080 || y== 1260 || y== 1440 || y== 1620 || y== 1800){
                    txtResultado.setText("0");
                    txtOperacion.setText("");
                }else {
                    y = (float) Math.toRadians(y);
                    txtResultado.setText(Float.toString((float) Math.sin(y)));
                    txtOperacion.setText("");
                }
            }
            case "Cos" -> {
                if(y== 90 || y== 90+(1*180) || y== 90+(2*180) || y== 90+(3*180) || y== 90+(4*180) || y== 90+(5*180) || y== 90+(6*180) || y== 90+(7*180) || y== 90+(8*180) || y== 90+(9*180)){
                    txtResultado.setText("0");
                    txtOperacion.setText("");
                }else {
                    y = (float) Math.toRadians(y);
                    txtResultado.setText(Float.toString((float) Math.cos(y)));
                    txtOperacion.setText("");
                }
            }
            case "Tan" -> {
                if(y== 90 || y== 90+(1*180) || y== 90+(2*180) || y== 90+(3*180) || y== 90+(4*180) || y== 90+(5*180) || y== 90+(6*180) || y== 90+(7*180) || y== 90+(8*180) || y== 90+(9*180)){
                    txtResultado.setText("ERROR");
                    txtOperacion.setText("");
                }else if(y== 180 || y== 360 || y== 540 || y== 720 || y== 900 || y== 1080 || y== 1260 || y== 1440 || y== 1620 || y== 1800){
                    txtResultado.setText("0");
                    txtOperacion.setText("");
                }else {
                    y = (float) Math.toRadians(y);
                    txtResultado.setText(Float.toString((float) Math.sin(y)));
                    txtOperacion.setText("");
                }
            }
            case"IVA" -> {
                z = x+((x*y)/100);
                txtResultado.setText(Float.toString(z));
                txtOperacion.setText("");
            }
        }
    }//GEN-LAST:event_btn_igualActionPerformed

    private void btn_acActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_acActionPerformed
        String texto = txtOperacion.getText().substring(0,txtOperacion.getText().length()-1);
        txtOperacion.setText(texto);
    }//GEN-LAST:event_btn_acActionPerformed

    public void addNumber(String digito){
        txtOperacion.setText(txtOperacion.getText()+digito);
    }
    public static void main(String args[]) {
        
       try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Calculadora.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Calculadora().setVisible(true);
       });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_0;
    private javax.swing.JButton btn_00;
    private javax.swing.JButton btn_1;
    private javax.swing.JButton btn_2;
    private javax.swing.JButton btn_3;
    private javax.swing.JButton btn_4;
    private javax.swing.JButton btn_5;
    private javax.swing.JButton btn_6;
    private javax.swing.JButton btn_7;
    private javax.swing.JButton btn_8;
    private javax.swing.JButton btn_9;
    private javax.swing.JButton btn_IVA;
    private javax.swing.JButton btn_Raiz;
    private javax.swing.JButton btn_ac;
    private javax.swing.JButton btn_c;
    private javax.swing.JButton btn_cos;
    private javax.swing.JButton btn_div;
    private javax.swing.JButton btn_exp;
    private javax.swing.JButton btn_igual;
    private javax.swing.JButton btn_men;
    private javax.swing.JButton btn_mul;
    private javax.swing.JButton btn_sin;
    private javax.swing.JButton btn_sum;
    private javax.swing.JButton btn_tan;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel txtOperacion;
    private javax.swing.JLabel txtResultado;
    // End of variables declaration//GEN-END:variables
}
