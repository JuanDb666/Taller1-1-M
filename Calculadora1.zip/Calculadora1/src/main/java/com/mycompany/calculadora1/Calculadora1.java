package com.mycompany.calculadora1;

import static java.lang.Math.sin;
import java.util.Scanner;


public class Calculadora1 {

    public static void main(String[] args) {
        Scanner p = new Scanner(System.in);
        int opcion;
        float num1;
        float num2;
        double resultado;
        
          
        do{
             System.out.println("\n\nBienvenido a la app calculadora \n\nSeleccione la opcion que desea usar:\n\n\t1. Suma\n\t2. Resta\n\t3. Multiplicación"
             + "\n\t4. División\n\t5. Seno\n\t6. Coseno\n\t7. Tangente\n\t8. Raiz\n\t9. Potencia\n\t10. Porcentaje de IVA\n\t11. SALIR");
            opcion= p.nextInt();
        while(opcion<0 || opcion>11){
             System.out.println("Opcion seleccionada invalida (no esta progrmada)\n\nPor favor seleccione una opcion programada\n\n");
             System.out.println("Bienvenido a la app calculadora \n\nSeleccione la opcion que desea usar:\n\n\t1. Suma\n\t2. Resta\n\t3. Multiplicación"
                + "\n\t4. División\n\t5. Seno\n\t6. Coseno\n\t7. Tangente\n\t8. Raiz\n\t9. Potencia\n\t10. Porcentaje de IVA\n\t11. SALIR");
            opcion= p.nextInt();
        }
            switch(opcion){
                case 1: {
                    System.out.println("\nIngrese el primer valor que desea sumar:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese el segundo valor que desea sumar:    ");
                    num2=p.nextFloat();
                    Operaciones.sumar(num1,num2);
                    break;
                }
                case 2 : {
                    System.out.println("\nIngrese el primer valor que desea restar:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese el segundo valor que desea restar:    ");
                    num2=p.nextFloat();
                    Operaciones.restar(num1, num2);
                    break;
                }
                case 3 : {
                    System.out.println("\nIngrese el primer valor que desea multiplicar:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese el segundo valor que desea multiplicar:    ");
                    num2=p.nextFloat();
                    Operaciones.multiplicar(num1, num2);
                    break;
                }
                case 4 : {
                    System.out.println("\nIngrese el primer valor que desea dividir:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese el segundo valor que desea dividir:    ");
                    num2=p.nextFloat();
                    if (num2 == 0){
                        System.out.println("\n\nNo es posible realizar divisiones en 0 ");
                    } else {
                        Operaciones.dividir(num1, num2);
                    }
                    break;
                }
                case 5 : {
                    System.out.println("\nIngrese el angulo del que desea medir el seno:    ");
                    num1=p.nextFloat();
                    num2=(float) Math.toRadians(num1);
                    Operaciones.seno(num1, num2);
                    break;
                }
                case 6 : {
                    System.out.println("\nIngrese el angulo del que desea medir el coseno:    ");
                    num1=p.nextFloat();
                    num2=(float) Math.toRadians(num1);
                    Operaciones.coseno(num1, num2);
                    break;
                }
                case 7 :{
                    double r;
                    System.out.println("\nIngrese el angulo del que desea medir la tangente:    ");
                    num1=p.nextFloat();
                    num2=(float) Math.toRadians(num1);
                    Operaciones.tangente(num1, num2);
                    break;
                }
                case 8 :{
                    System.out.println("\nIngrese el numero del que desea conocer la raiz:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese la raiz que desea calcular:   ");
                    num2=p.nextFloat();
                    Operaciones.raiz(num1, num2);
                    break;
                }
                case 9:{
                    System.out.println("\nIngrese el numero del que desea conocer la potencia:    ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese la potencia que desea calcular:   ");
                    num2=p.nextFloat();
                    Operaciones.potencia(num1, num2);
                    break;
                }
                case 10:{
                    System.out.println("\nIngrese el valor del producto ");
                    num1=p.nextFloat();
                    System.out.println("\nIngrese el valor del IVA  ");
                    num2=p.nextFloat();
                    Operaciones.IVA(num1, num2);
                    break;
                }
                case 11:{
                    System.out.println("\nGracias por usar la calculadora");
                    break;
                }
                default :{
                    System.out.println("\n\nOpcion no programada");
                }
            }
        }while (opcion != 11);
    }
}