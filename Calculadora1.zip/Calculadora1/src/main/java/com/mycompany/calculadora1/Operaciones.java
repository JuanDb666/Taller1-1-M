
package com.mycompany.calculadora1;

import java.util.Scanner;

public class Operaciones {
    static float a;
    static float b;
    static float c;
    public static void sumar (float a, float b){
        c = a + b;
        System.out.println("\n\nEl resultado de la suma de "+a+" + " +b+" = "+c);
    }
    
    public static void restar (float a, float b){
        c=a-b;
        System.out.println("\n\nEl resultado de la resta de "+a+" - " +b+" = "+c);
    }
    
    public static void multiplicar (float a, float b){
        c=a*b;
       System.out.println("\n\nEl resultado de la multiplicación de "+a+" x " +b+" = "+c); 
    }
    
    public static void dividir (float a, float b){
        c=a/b;
       System.out.println("\n\nEl resultado de la multiplicación de "+a+" / " +b+" = "+c);
    }
    
    
    public static void seno (float a, float b){
        if(a== 180 || a== 360 || a== 540 || a== 720 || a== 900 || a== 1080 || a== 1260 || a== 1440 || a== 1620 || a== 1800){
                c=0;
                System.out.println("\n\nEl resultado de coseno de "+a+" = "+c);
                }else { 
                    c = (float) Math.sin(b);
                System.out.println("\n\nEl resultado de seno de "+a+" = "+c);
                }
    }
    public static void coseno (float a, float b){
        if(a== 90 || a== 90+(1*180) || a== 90+(2*180) || a== 90+(3*180) || a== 90+(4*180) || a== 90+(5*180) || a== 90+(6*180) || a== 90+(7*180) || a== 90+(8*180) || a== 90+(9*180)){
                c=0;
                System.out.println("\n\nEl resultado de coseno de "+a+" = "+c);
                }else {  
                    c = (float) Math.cos(b);    
                System.out.println("\n\nEl resultado de coseno de "+a+" = "+c);
                }
    }
    public static void tangente (float a, float b){
        if(a== 90 || a== 90+(1*180) || a== 90+(2*180) || a== 90+(3*180) || a== 90+(4*180) || a== 90+(5*180) || a== 90+(6*180) || a== 90+(7*180) || a== 90+(8*180) || a== 90+(9*180)){
                System.out.println("Tangente indeterminada");
                }else if(a== 180 || a== 360 || a== 540 || a== 720 || a== 900 || a== 1080 || a== 1260 || a== 1440 || a== 1620 || a== 1800){
                c=0;
                System.out.println("\n\nEl resultado de coseno de "+a+" = "+c);
                }else { 
                    c = (float) Math.tan(b);    
                System.out.println("\n\nEl resultado de tangente de "+a+" = "+c);
                }
    }
    public static void raiz (float a, float b){
        if(a < 0){
                  System.out.println("\n\nNo se pueden realizar raíces negativas");
        } else {
            c=(float) Math.pow(a,1/b);
            System.out.println("\n\nEl resultado de la raiz "+b+" de "+a+" = "+c);
        }   
    }
    public static void potencia (float a, float b){
        c=(float) Math.pow(a,b);
            System.out.println("\n\nEl resultado de la raiz "+b+" de "+a+" = "+c);
    }
    public static void IVA (float a, float b){
        c = a + ((a*b)/100);
        System.out.println("\n\nEl valor es  "+c);
    }
}
